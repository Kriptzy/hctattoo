import React from 'react';

export default function About() {
  return (
    <div>
    <div className="about-container">
      <div className="about-image-container">
        <div className="background-about"></div>
        <div className="about-title-container">
          <div className="about-title">Sobre</div>
        </div>
      </div>
    </div>
    <div className="about-text">
        colocar o sobre mim.
      </div>
    </div>
  );
};